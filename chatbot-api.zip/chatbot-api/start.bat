@echo off
cd /d "%~dp0"

echo ========================================
echo   Nexora Chatbot API - Starting...
echo ========================================

start "NexoraChatbot" cmd /c "cd /d "%~dp0app" && python main.py"
start "Ngrok" cmd /c "ngrok http 8000 --log=stdout"

echo.
echo Server and ngrok starting in background...
echo.
echo   Server:  http://localhost:8000
echo   ngrok:   http://127.0.0.1:4040
echo.
echo Press any key to stop all services...
pause >nul

echo Shutting down...
taskkill /f /fi "WINDOWTITLE eq NexoraChatbot" >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq Ngrok" >nul 2>&1
echo Done.
